
yolov8 training - v2 2025-03-10 10:30am
==============================

This dataset was exported via roboflow.com on March 10, 2025 at 3:31 AM GMT

Roboflow is an end-to-end computer vision platform that helps you
* collaborate with your team on computer vision projects
* collect & organize images
* understand and search unstructured image data
* annotate, and create datasets
* export, train, and deploy computer vision models
* use active learning to improve your dataset over time

For state of the art Computer Vision training notebooks you can use with this dataset,
visit https://github.com/roboflow/notebooks

To find over 100k other datasets and pre-trained models, visit https://universe.roboflow.com

The dataset includes 61 images.
Objects are annotated in YOLOv8 format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 640x640 (Fill (with center crop))

The following augmentation was applied to create 3 versions of each source image:
* Random rotation of between -5 and +5 degrees
* Random shear of between -5° to +5° horizontally and -7° to +7° vertically


